import os

import pytest
from fastapi.testclient import TestClient

from app.main import app


@pytest.fixture
def client():
    return TestClient(app)


@pytest.fixture
def user_token(client):
    email = "pytest_user@example.com"
    password = "Test@123"

    # Register test user
    client.post(
        "/auth/register",
        json={
            "name": "Pytest User",
            "email": email,
            "phone": "9876543210",
            "password": password,
        },
    )

    # Login
    response = client.post(
        "/auth/login",
        json={
            "email": email,
            "password": password,
        },
    )

    assert response.status_code == 200

    return response.json()["access_token"]

@pytest.fixture
def normal_user_token(client):
    email = "pytest_normal_user@example.com"
    password = "Test@123"

    # Register normal user
    client.post(
        "/auth/register",
        json={
            "name": "Pytest Normal User",
            "email": email,
            "phone": "9876543212",
            "password": password,
        },
    )

    # Login
    response = client.post(
        "/auth/login",
        json={
            "email": email,
            "password": password,
        },
    )

    assert response.status_code == 200

    return response.json()["access_token"]

import os


@pytest.fixture
def admin_token(client):
    email = "sam@example.com"
    password = os.getenv("TEST_ADMIN_PASSWORD")

    if not password:
        pytest.fail(
            "TEST_ADMIN_PASSWORD environment variable is not set"
        )

    response = client.post(
        "/auth/login",
        json={
            "email": email,
            "password": password,
        },
    )

    assert response.status_code == 200

    return response.json()["access_token"]

import os
import pytest
from fastapi.testclient import TestClient
from app.main import app


@pytest.fixture
def client():
    return TestClient(app)


@pytest.fixture
def admin_token(client):
    email = "sam@example.com"
    password = os.getenv("TEST_ADMIN_PASSWORD")

    if not password:
        pytest.fail("TEST_ADMIN_PASSWORD environment variable is not set")

    response = client.post(
        "/auth/login",
        json={
            "email": email,
            "password": password
        }
    )

    assert response.status_code == 200

    return response.json()["access_token"]