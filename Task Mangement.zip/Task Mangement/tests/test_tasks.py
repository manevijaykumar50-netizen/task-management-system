def test_get_tasks_without_token(client):
    response = client.get("/tasks/")

    assert response.status_code == 401


def test_get_tasks_with_token(client, user_token):
    response = client.get(
        "/tasks/",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
    )

    assert response.status_code == 200


def test_get_invalid_task(client, user_token):
    response = client.get(
        "/tasks/99999",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
    )

    assert response.status_code == 404
    assert response.json()["detail"] == "Task not found"


def test_invalid_pagination(client, user_token):
    response = client.get(
        "/tasks/?page=0",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
    )

    assert response.status_code == 422
    
def test_create_task(client, user_token):
    response = client.post(
        "/tasks/",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
        json={
            "title": "Pytest Task",
            "description": "Task created through automated testing",
            "priority": "high"
        },
    )

    assert response.status_code in [200, 201]

    data = response.json()

    assert data["title"] == "Pytest Task"
    assert data["description"] == "Task created through automated testing"
    assert data["priority"] == "high"
    assert data["status"] == "todo"
    
def test_task_status_todo_to_in_progress(client, user_token):
    # Create task
    create_response = client.post(
        "/tasks/",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
        json={
            "title": "Status Test Task",
            "priority": "medium"
        },
    )

    assert create_response.status_code in [200, 201]

    task_id = create_response.json()["id"]

    # Change status
    response = client.put(
        f"/tasks/{task_id}/status",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
        json={
            "status": "in_progress"
        },
    )

    assert response.status_code == 200
    assert response.json()["status"] == "in_progress"
    
def test_task_status_in_progress_to_completed(client, user_token):
    # Create task
    create_response = client.post(
        "/tasks/",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
        json={
            "title": "Complete Test Task",
            "priority": "high"
        },
    )

    assert create_response.status_code in [200, 201]

    task_id = create_response.json()["id"]

    # TODO → IN_PROGRESS
    response = client.put(
        f"/tasks/{task_id}/status",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
        json={
            "status": "in_progress"
        },
    )

    assert response.status_code == 200

    # IN_PROGRESS → COMPLETED
    response = client.put(
        f"/tasks/{task_id}/status",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
        json={
            "status": "completed"
        },
    )

    assert response.status_code == 200
    assert response.json()["status"] == "completed"
    
def test_completed_task_cannot_be_modified(client, user_token):
    # Create task
    create_response = client.post(
        "/tasks/",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
        json={
            "title": "Locked Task",
            "priority": "medium"
        },
    )

    assert create_response.status_code in [200, 201]

    task_id = create_response.json()["id"]

    # TODO → IN_PROGRESS
    response = client.put(
        f"/tasks/{task_id}/status",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
        json={
            "status": "in_progress"
        },
    )

    assert response.status_code == 200

    # IN_PROGRESS → COMPLETED
    response = client.put(
        f"/tasks/{task_id}/status",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
        json={
            "status": "completed"
        },
    )

    assert response.status_code == 200

    # Try changing completed task
    response = client.put(
        f"/tasks/{task_id}",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
        json={
            "title": "Trying To Change Completed Task"
        },
    )

    assert response.status_code == 400
    assert response.json()["detail"] == "Completed tasks cannot be modified"
    
def test_inactive_user_cannot_be_assigned_task(
    client,
    admin_token,
    user_token
):
    # 1. Create/find the test user
    email = "pytest_inactive@example.com"

    register_response = client.post(
        "/auth/register",
        json={
            "name": "Inactive Test User",
            "email": email,
            "phone": "9876543214",
            "password": "Test@123",
        },
    )

    assert register_response.status_code in [200, 201, 409]

    # 2. Get users using admin account
    users_response = client.get(
        "/users",
        headers={
            "Authorization": f"Bearer {admin_token}"
        },
    )

    assert users_response.status_code == 200

    users_data = users_response.json()

    users = users_data["items"]

    inactive_user = next(
    user for user in users
    if user["email"] == email
)

    user_id = inactive_user["id"]

    # 3. Deactivate the user
    deactivate_response = client.put(
        f"/users/{user_id}",
        headers={
            "Authorization": f"Bearer {admin_token}"
        },
        json={
            "status": "inactive"
        },
    )

    assert deactivate_response.status_code == 200
    assert deactivate_response.json()["status"] == "inactive"

    # 4. Create a task
    task_response = client.post(
        "/tasks/",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
        json={
            "title": "Inactive User Assignment Test",
            "priority": "high",
        },
    )

    assert task_response.status_code in [200, 201]

    task_id = task_response.json()["id"]

    # 5. Try assigning task to inactive user
    assign_response = client.put(
        f"/tasks/{task_id}/assign",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
        json={
            "assigned_user_id": user_id
        },
    )

    # 6. Assignment must be rejected
    assert assign_response.status_code == 400
    assert (
        assign_response.json()["detail"]
        == "Inactive users cannot be assigned tasks"
    )
    
def test_create_comment(client, user_token):
    # Create a task
    task_response = client.post(
        "/tasks/",
        headers={"Authorization": f"Bearer {user_token}"},
        json={
            "title": "Comment Test Task",
            "priority": "medium"
        },
    )

    assert task_response.status_code in [200, 201]

    task_id = task_response.json()["id"]

    # Create comment
    response = client.post(
        f"/comments/tasks/{task_id}",
        headers={"Authorization": f"Bearer {user_token}"},
        json={
            "content": "This is an automated test comment."
        },
    )

    assert response.status_code in [200, 201]

    data = response.json()

    assert data["content"] == "This is an automated test comment."
    assert data["task_id"] == task_id


def test_get_task_comments(client, user_token):
    # Create task
    task_response = client.post(
        "/tasks/",
        headers={"Authorization": f"Bearer {user_token}"},
        json={
            "title": "Get Comments Test Task",
            "priority": "low"
        },
    )

    assert task_response.status_code in [200, 201]

    task_id = task_response.json()["id"]

    # Add comment
    comment_response = client.post(
        f"/comments/tasks/{task_id}",
        headers={"Authorization": f"Bearer {user_token}"},
        json={
            "content": "Comment for retrieval test."
        },
    )

    assert comment_response.status_code in [200, 201]

    # Get comments
    response = client.get(
        f"/comments/tasks/{task_id}",
        headers={"Authorization": f"Bearer {user_token}"},
    )

    assert response.status_code == 200

    comments = response.json()

    assert len(comments) >= 1
    
def test_user_cannot_modify_another_users_comment(
    client,
    user_token,
    normal_user_token
):
    # User 1 creates a task
    task_response = client.post(
        "/tasks/",
        headers={"Authorization": f"Bearer {user_token}"},
        json={
            "title": "Comment Ownership Test",
            "priority": "medium"
        },
    )

    assert task_response.status_code in [200, 201]

    task_id = task_response.json()["id"]

    # User 1 creates a comment
    comment_response = client.post(
        f"/comments/tasks/{task_id}",
        headers={"Authorization": f"Bearer {user_token}"},
        json={
            "content": "User 1's comment."
        },
    )

    assert comment_response.status_code in [200, 201]

    comment_id = comment_response.json()["id"]

    # User 2 tries to modify User 1's comment
    response = client.put(
        f"/comments/{comment_id}",
        headers={"Authorization": f"Bearer {normal_user_token}"},
        json={
            "content": "User 2 is trying to modify this."
        },
    )

    assert response.status_code == 403
    assert response.json()["detail"] == "You can modify only your own comments"


def test_completed_task_cannot_receive_comment(client, user_token):
    # Create task
    task_response = client.post(
        "/tasks/",
        headers={"Authorization": f"Bearer {user_token}"},
        json={
            "title": "Completed Comment Test",
            "priority": "high"
        },
    )

    assert task_response.status_code in [200, 201]

    task_id = task_response.json()["id"]

    # TODO -> IN_PROGRESS
    response = client.put(
        f"/tasks/{task_id}/status",
        headers={"Authorization": f"Bearer {user_token}"},
        json={
            "status": "in_progress"
        },
    )

    assert response.status_code == 200

    # IN_PROGRESS -> COMPLETED
    response = client.put(
        f"/tasks/{task_id}/status",
        headers={"Authorization": f"Bearer {user_token}"},
        json={
            "status": "completed"
        },
    )

    assert response.status_code == 200

    # Try adding a comment to completed task
    response = client.post(
        f"/comments/tasks/{task_id}",
        headers={"Authorization": f"Bearer {user_token}"},
        json={
            "content": "This comment should be rejected."
        },
    )

    assert response.status_code == 400
    assert (
        response.json()["detail"]
        == "Completed or cancelled tasks cannot receive new comments"
    )
    
def test_upload_valid_attachment(client, user_token):
    # Create task
    task_response = client.post(
        "/tasks/",
        headers={"Authorization": f"Bearer {user_token}"},
        json={
            "title": "Attachment Upload Test",
            "priority": "medium"
        },
    )

    assert task_response.status_code in [200, 201]

    task_id = task_response.json()["id"]

    # Upload a valid TXT file
    response = client.post(
        f"/attachments/tasks/{task_id}",
        headers={"Authorization": f"Bearer {user_token}"},
        files={
            "file": (
                "test.txt",
                b"This is a pytest attachment.",
                "text/plain"
            )
        },
    )

    assert response.status_code in [200, 201]

    data = response.json()

    assert data["task_id"] == task_id
    assert data["original_filename"] == "test.txt"


def test_reject_unsupported_attachment(client, user_token):
    # Create task
    task_response = client.post(
        "/tasks/",
        headers={"Authorization": f"Bearer {user_token}"},
        json={
            "title": "Invalid Attachment Test",
            "priority": "low"
        },
    )

    assert task_response.status_code in [200, 201]

    task_id = task_response.json()["id"]

    # Try uploading unsupported EXE file
    response = client.post(
        f"/attachments/tasks/{task_id}",
        headers={"Authorization": f"Bearer {user_token}"},
        files={
            "file": (
                "malware.exe",
                b"fake executable content",
                "application/octet-stream"
            )
        },
    )

    assert response.status_code == 400
    assert "unsupported file type" in response.json()["detail"].lower()


def test_delete_attachment(client, user_token):
    # Create task
    task_response = client.post(
        "/tasks/",
        headers={"Authorization": f"Bearer {user_token}"},
        json={
            "title": "Attachment Delete Test",
            "priority": "medium"
        },
    )

    assert task_response.status_code in [200, 201]

    task_id = task_response.json()["id"]

    # Upload attachment
    upload_response = client.post(
        f"/attachments/tasks/{task_id}",
        headers={"Authorization": f"Bearer {user_token}"},
        files={
            "file": (
                "delete_test.txt",
                b"Attachment that will be deleted.",
                "text/plain"
            )
        },
    )

    assert upload_response.status_code in [200, 201]

    attachment_id = upload_response.json()["id"]

    # Delete attachment
    delete_response = client.delete(
        f"/attachments/{attachment_id}",
        headers={"Authorization": f"Bearer {user_token}"},
    )

    assert delete_response.status_code == 204
    
def test_comments_require_authentication(client, user_token):
    response = client.get("/comments/tasks/99999")

    assert response.status_code == 401


def test_attachments_require_authentication(client):
    response = client.get("/attachments/tasks/99999")

    assert response.status_code == 401


def test_user_cannot_access_another_users_task(
    client,
    user_token,
    normal_user_token
):
    # User 1 creates a task
    task_response = client.post(
        "/tasks/",
        headers={"Authorization": f"Bearer {user_token}"},
        json={
            "title": "Private Task Security Test",
            "priority": "medium"
        },
    )

    assert task_response.status_code in [200, 201]

    task_id = task_response.json()["id"]

    # User 2 tries to access it
    response = client.get(
        f"/tasks/{task_id}",
        headers={
            "Authorization": f"Bearer {normal_user_token}"
        },
    )

    assert response.status_code == 403
    assert response.json()["detail"] == "You are not authorized to access this task"
    
def test_get_notifications(client, user_token):
    response = client.get(
        "/notifications",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
    )

    assert response.status_code == 200

    data = response.json()

    assert isinstance(data, dict)
    assert "items" in data
    assert "total" in data
    assert "unread_count" in data
    assert isinstance(data["items"], list)


def test_mark_notification_as_read(client, user_token):
    # Get existing notifications
    notifications_response = client.get(
        "/notifications",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
    )

    assert notifications_response.status_code == 200

    data = notifications_response.json()
    notifications = data["items"]

    # If there are no notifications, skip this test
    if not notifications:
        import pytest
        pytest.skip("No notifications available for testing")

    notification_id = notifications[0]["id"]

    # Mark notification as read
    response = client.put(
        f"/notifications/{notification_id}/read",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
    )

    assert response.status_code == 200
    
def test_task_assignment_creates_notification(
    client,
    admin_token,
    user_token,
    normal_user_token
):
    # Get users as admin
    users_response = client.get(
        "/users",
        headers={
            "Authorization": f"Bearer {admin_token}"
        },
    )

    assert users_response.status_code == 200

    users_data = users_response.json()
    users = users_data["items"]

    # Find the normal test user
    target_user = next(
        user for user in users
        if user["email"] == "pytest_normal_user@example.com"
    )

    target_user_id = target_user["id"]

    # Create task as User 1
    task_response = client.post(
        "/tasks/",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
        json={
            "title": "Notification Assignment Test",
            "priority": "high"
        },
    )

    assert task_response.status_code in [200, 201]

    task_id = task_response.json()["id"]

    # Assign task to User 2
    assign_response = client.put(
        f"/tasks/{task_id}/assign",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
        json={
            "assigned_user_id": target_user_id
        },
    )

    assert assign_response.status_code == 200

    # Check User 2 notifications
    notifications_response = client.get(
        "/notifications",
        headers={
            "Authorization": f"Bearer {normal_user_token}"
        },
    )

    assert notifications_response.status_code == 200

    notifications_data = notifications_response.json()
    notifications = notifications_data["items"]

    assert len(notifications) >= 1

    # Verify assignment notification exists
    assignment_notification = next(
        notification
        for notification in notifications
        if "assign" in notification["title"].lower()
        or "assign" in notification["message"].lower()
    )

    assert assignment_notification is not None
    
def test_mark_generated_notification_as_read(
    client,
    admin_token,
    user_token,
    normal_user_token
):
    # Get User 2 ID
    users_response = client.get(
        "/users",
        headers={
            "Authorization": f"Bearer {admin_token}"
        },
    )

    assert users_response.status_code == 200

    users = users_response.json()["items"]

    target_user = next(
        user for user in users
        if user["email"] == "pytest_normal_user@example.com"
    )

    target_user_id = target_user["id"]

    # Create task
    task_response = client.post(
        "/tasks/",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
        json={
            "title": "Mark Notification Read Test",
            "priority": "medium"
        },
    )

    assert task_response.status_code in [200, 201]

    task_id = task_response.json()["id"]

    # Assign task to User 2
    assign_response = client.put(
        f"/tasks/{task_id}/assign",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
        json={
            "assigned_user_id": target_user_id
        },
    )

    assert assign_response.status_code == 200

    # Get User 2 notifications
    notifications_response = client.get(
        "/notifications",
        headers={
            "Authorization": f"Bearer {normal_user_token}"
        },
    )

    assert notifications_response.status_code == 200

    notifications = notifications_response.json()["items"]

    assert len(notifications) >= 1

# Debug: show actual notifications

    notification = notifications[0]
    notification_id = notification["id"]

    notification_id = notification["id"]

    # Mark notification as read
    read_response = client.put(
        f"/notifications/{notification_id}/read",
        headers={
            "Authorization": f"Bearer {normal_user_token}"
        },
    )

    assert read_response.status_code == 200
    
def test_task_creation_creates_audit_log(
    client,
    admin_token,
    user_token
):
    # Create a task
    task_response = client.post(
        "/tasks/",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
        json={
            "title": "Audit Log Test Task",
            "description": "Testing automatic audit logging",
            "priority": "medium"
        },
    )

    assert task_response.status_code in [200, 201]

    task_id = task_response.json()["id"]

    # Get audit logs as admin
    audit_response = client.get(
        "/audit-logs",
        headers={
            "Authorization": f"Bearer {admin_token}"
        },
    )

    assert audit_response.status_code == 200

    audit_data = audit_response.json()

    # Check response contains audit logs
    assert "items" in audit_data

    audit_logs = audit_data["items"]

    matching_logs = [
    log
    for log in audit_logs
    if log.get("entity_id") == task_id
    and log.get("action") == "create"
    and log.get("entity_type") == "task"
]

    assert len(matching_logs) >= 1
    
def test_task_assignment_creates_audit_log(
    client,
    admin_token,
    user_token,
    normal_user_token
):
    # Get target user ID
    users_response = client.get(
        "/users",
        headers={
            "Authorization": f"Bearer {admin_token}"
        },
    )

    assert users_response.status_code == 200

    users = users_response.json()["items"]

    target_user = next(
        user for user in users
        if user["email"] == "pytest_normal_user@example.com"
    )

    target_user_id = target_user["id"]

    # Create task
    task_response = client.post(
        "/tasks/",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
        json={
            "title": "Audit Assignment Test",
            "priority": "medium"
        },
    )

    assert task_response.status_code in [200, 201]

    task_id = task_response.json()["id"]

    # Assign task
    assign_response = client.put(
        f"/tasks/{task_id}/assign",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
        json={
            "assigned_user_id": target_user_id
        },
    )

    assert assign_response.status_code == 200

    # Get audit logs
    audit_response = client.get(
        "/audit-logs",
        headers={
            "Authorization": f"Bearer {admin_token}"
        },
    )

    assert audit_response.status_code == 200

    audit_logs = audit_response.json()["items"]

    # Verify ASSIGN audit log
    matching_logs = [
        log
        for log in audit_logs
        if log.get("entity_id") == task_id
        and log.get("entity_type") == "task"
        and log.get("action") == "assign"
    ]

    assert len(matching_logs) >= 1
    
def test_task_status_change_creates_audit_log(
    client,
    admin_token,
    user_token
):
    # Create task
    task_response = client.post(
        "/tasks/",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
        json={
            "title": "Audit Status Change Test",
            "priority": "medium"
        },
    )

    assert task_response.status_code in [200, 201]

    task_id = task_response.json()["id"]

    # Change status to IN_PROGRESS
    status_response = client.put(
        f"/tasks/{task_id}/status",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
        json={
            "status": "in_progress"
        },
    )

    assert status_response.status_code == 200

    # Get audit logs
    audit_response = client.get(
        "/audit-logs",
        headers={
            "Authorization": f"Bearer {admin_token}"
        },
    )

    assert audit_response.status_code == 200

    audit_logs = audit_response.json()["items"]

    # Verify status change audit log
    matching_logs = [
        log
        for log in audit_logs
        if log.get("entity_id") == task_id
        and log.get("entity_type") == "task"
        and log.get("action") == "status_change"
    ]

    assert len(matching_logs) >= 1
    
def test_task_priority_change_creates_audit_log(
    client,
    admin_token,
    user_token
):
    # Create task
    task_response = client.post(
        "/tasks/",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
        json={
            "title": "Audit Priority Change Test",
            "priority": "medium"
        },
    )

    assert task_response.status_code in [200, 201]

    task_id = task_response.json()["id"]

    # Change priority to HIGH
    priority_response = client.put(
        f"/tasks/{task_id}/priority",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
        json={
            "priority": "high"
        },
    )

    assert priority_response.status_code == 200

    # Get audit logs as admin
    audit_response = client.get(
        "/audit-logs",
        headers={
            "Authorization": f"Bearer {admin_token}"
        },
    )

    assert audit_response.status_code == 200

    audit_logs = audit_response.json()["items"]

    # Verify priority change audit log
    matching_logs = [
        log
        for log in audit_logs
        if log.get("entity_id") == task_id
        and log.get("entity_type") == "task"
        and log.get("action") == "priority_change"
    ]

    assert len(matching_logs) >= 1
    
def test_task_update_creates_audit_log(
    client,
    admin_token,
    user_token
):
    # Create task
    task_response = client.post(
        "/tasks/",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
        json={
            "title": "Audit Update Test",
            "description": "Original description",
            "priority": "medium"
        },
    )

    assert task_response.status_code in [200, 201]

    task_id = task_response.json()["id"]

    # Update task
    update_response = client.put(
        f"/tasks/{task_id}",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
        json={
            "title": "Updated Audit Test",
            "description": "Updated description"
        },
    )

    assert update_response.status_code == 200

    # Get audit logs
    audit_response = client.get(
        "/audit-logs",
        headers={
            "Authorization": f"Bearer {admin_token}"
        },
    )

    assert audit_response.status_code == 200

    audit_logs = audit_response.json()["items"]

    # Verify update audit log
    matching_logs = [
        log
        for log in audit_logs
        if log.get("entity_id") == task_id
        and log.get("entity_type") == "task"
        and log.get("action") == "update"
    ]

    assert len(matching_logs) >= 1
    
def test_task_delete_creates_audit_log(
    client,
    admin_token,
    user_token
):
    # Create task
    task_response = client.post(
        "/tasks/",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
        json={
            "title": "Audit Delete Test",
            "description": "Task to test delete audit logging",
            "priority": "medium"
        },
    )

    assert task_response.status_code in [200, 201]

    task_id = task_response.json()["id"]

    # Delete task
    delete_response = client.delete(
        f"/tasks/{task_id}",
        headers={
            "Authorization": f"Bearer {user_token}"
        },
    )

    assert delete_response.status_code in [200, 204]

    # Get audit logs as admin
    audit_response = client.get(
        "/audit-logs",
        headers={
            "Authorization": f"Bearer {admin_token}"
        },
    )

    assert audit_response.status_code == 200

    audit_logs = audit_response.json()["items"]

    # Verify delete audit log
    matching_logs = [
        log
        for log in audit_logs
        if log.get("entity_id") == task_id
        and log.get("entity_type") == "task"
        and log.get("action") == "delete"
    ]

    assert len(matching_logs) >= 1