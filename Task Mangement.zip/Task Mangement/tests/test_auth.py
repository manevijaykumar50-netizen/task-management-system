def test_register_user(client):
    response = client.post(
        "/auth/register",
        json={
            "name": "Test Registration User",
            "email": "registration_test@example.com",
            "phone": "9876543211",
            "password": "Test@123",
        },
    )

    # 200/201 = successfully registered
    # 409 = user already exists from a previous test run
    assert response.status_code in [200, 201, 409]


def test_login_invalid_password(client):
    response = client.post(
        "/auth/login",
        json={
            "email": "pytest_user@example.com",
            "password": "WrongPassword123",
        },
    )

    assert response.status_code == 401
    assert response.json()["detail"] == "Invalid email or password"
    
def test_normal_user_cannot_access_admin_users(client, normal_user_token):
    response = client.get(
        "/users/",
        headers={
            "Authorization": f"Bearer {normal_user_token}"
        },
    )

    assert response.status_code == 403
    assert response.json()["detail"] == "Admin access required"