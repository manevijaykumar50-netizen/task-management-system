from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

from app.utils.enums import TaskPriority, TaskStatus


class TaskCreateRequest(BaseModel):
    title: str = Field(
        min_length=1,
        max_length=200
    )

    description: str | None = None

    assigned_user_id: int | None = Field(
        default=None,
        gt=0
    )

    priority: TaskPriority = TaskPriority.MEDIUM

    due_date: datetime | None = None


class TaskUpdateRequest(BaseModel):
    title: str | None = Field(
        default=None,
        min_length=1,
        max_length=200
    )

    description: str | None = None

    due_date: datetime | None = None


class TaskAssignRequest(BaseModel):
    assigned_user_id: int = Field(
        gt=0
    )


class TaskStatusRequest(BaseModel):
    status: TaskStatus


class TaskPriorityRequest(BaseModel):
    priority: TaskPriority


class TaskResponse(BaseModel):
    id: int
    title: str
    description: str | None
    assigned_user_id: int | None
    created_by_id: int
    priority: TaskPriority
    status: TaskStatus
    due_date: datetime | None
    created_at: datetime
    updated_at: datetime
    completed_at: datetime | None

    model_config = ConfigDict(
        from_attributes=True
    )


class TaskListResponse(BaseModel):
    items: list[TaskResponse]
    total: int
    page: int
    limit: int
    pages: int