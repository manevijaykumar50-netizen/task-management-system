from datetime import datetime

from pydantic import BaseModel, ConfigDict

from app.utils.enums import AuditAction, EntityType


class AuditLogResponse(BaseModel):
    id: int
    user_id: int
    action: AuditAction
    entity_type: EntityType
    entity_id: int
    timestamp: datetime

    model_config = ConfigDict(from_attributes=True)


class AuditLogListResponse(BaseModel):
    items: list[AuditLogResponse]
    total: int