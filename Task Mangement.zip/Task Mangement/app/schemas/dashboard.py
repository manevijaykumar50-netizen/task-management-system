from pydantic import BaseModel


class TaskStatusSummary(BaseModel):
    todo: int
    in_progress: int
    completed: int
    cancelled: int


class TaskPrioritySummary(BaseModel):
    low: int
    medium: int
    high: int
    critical: int


class AdminDashboardResponse(BaseModel):
    total_users: int
    active_users: int
    inactive_users: int

    total_tasks: int

    task_status: TaskStatusSummary
    task_priority: TaskPrioritySummary


class UserDashboardResponse(BaseModel):
    created_tasks: int
    assigned_tasks: int

    todo_tasks: int
    in_progress_tasks: int
    completed_tasks: int
    cancelled_tasks: int

    overdue_tasks: int