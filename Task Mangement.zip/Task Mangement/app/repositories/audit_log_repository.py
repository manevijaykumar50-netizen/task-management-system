from sqlalchemy.orm import Session

from app.models.audit_log import AuditLog
from app.utils.enums import EntityType

class AuditLogRepository:

    def __init__(self, db: Session):
        self.db = db

    def create(self, audit_log: AuditLog) -> AuditLog:
        self.db.add(audit_log)
        self.db.commit()
        self.db.refresh(audit_log)
        return audit_log

    def get_by_id(self, audit_log_id: int) -> AuditLog | None:
        return (
            self.db.query(AuditLog)
            .filter(AuditLog.id == audit_log_id)
            .first()
        )

    def get_all(self) -> list[AuditLog]:
        return (
            self.db.query(AuditLog)
            .order_by(AuditLog.timestamp.desc())
            .all()
        )

    def get_by_user(self, user_id: int) -> list[AuditLog]:
        return (
            self.db.query(AuditLog)
            .filter(AuditLog.user_id == user_id)
            .order_by(AuditLog.timestamp.desc())
            .all()
        )

    def get_by_entity(
        self,
        entity_type: EntityType,
        entity_id: int
    ) -> list[AuditLog]:
        return (
            self.db.query(AuditLog)
            .filter(
                AuditLog.entity_type == entity_type,
                AuditLog.entity_id == entity_id
            )
            .order_by(AuditLog.timestamp.desc())
            .all()
        )

    def count(self) -> int:
        return self.db.query(AuditLog).count()