from sqlalchemy import func, or_
from sqlalchemy.orm import Session

from app.models.task import Task
from app.utils.enums import TaskPriority, TaskStatus


class TaskRepository:

    def __init__(self, db: Session):
        self.db = db

    def create(self, task: Task) -> Task:
        self.db.add(task)
        self.db.commit()
        self.db.refresh(task)

        return task

    def get_by_id(
        self,
        task_id: int
    ) -> Task | None:

        return (
            self.db.query(Task)
            .filter(Task.id == task_id)
            .first()
        )

    def update(self, task: Task) -> Task:
        self.db.commit()
        self.db.refresh(task)

        return task

    def delete(self, task: Task) -> None:
        self.db.delete(task)
        self.db.commit()

    def count(
        self,
        query
    ) -> int:
        return query.count()

    def get_tasks(
        self,
        query,
        page: int,
        limit: int
    ) -> list[Task]:

        offset = (page - 1) * limit

        return (
            query
            .offset(offset)
            .limit(limit)
            .all()
        )