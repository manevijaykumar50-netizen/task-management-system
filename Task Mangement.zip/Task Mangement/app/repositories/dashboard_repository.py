from datetime import datetime, timezone

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.models.task import Task
from app.models.user import User
from app.utils.enums import (
    TaskPriority,
    TaskStatus,
    UserStatus,
)


class DashboardRepository:

    def __init__(self, db: Session):
        self.db = db

    # ---------------------------------------------------------
    # USER COUNTS
    # ---------------------------------------------------------

    def total_users(self) -> int:

        return self.db.query(User).count()

    def active_users(self) -> int:

        return (
            self.db.query(User)
            .filter(User.status == UserStatus.ACTIVE)
            .count()
        )

    def inactive_users(self) -> int:

        return (
            self.db.query(User)
            .filter(User.status == UserStatus.INACTIVE)
            .count()
        )

    # ---------------------------------------------------------
    # TASK COUNTS
    # ---------------------------------------------------------

    def total_tasks(self) -> int:

        return self.db.query(Task).count()

    def tasks_by_status(
        self,
        task_status: TaskStatus,
    ) -> int:

        return (
            self.db.query(Task)
            .filter(Task.status == task_status)
            .count()
        )

    def tasks_by_priority(
        self,
        priority: TaskPriority,
    ) -> int:

        return (
            self.db.query(Task)
            .filter(Task.priority == priority)
            .count()
        )

    # ---------------------------------------------------------
    # USER CREATED TASKS
    # ---------------------------------------------------------

    def created_tasks(
        self,
        user_id: int,
    ) -> int:

        return (
            self.db.query(Task)
            .filter(Task.created_by_id == user_id)
            .count()
        )

    # ---------------------------------------------------------
    # USER ASSIGNED TASKS
    # ---------------------------------------------------------

    def assigned_tasks(
        self,
        user_id: int,
    ) -> int:

        return (
            self.db.query(Task)
            .filter(Task.assigned_user_id == user_id)
            .count()
        )

    # ---------------------------------------------------------
    # USER TASK STATUS
    # ---------------------------------------------------------

    def user_tasks_by_status(
        self,
        user_id: int,
        task_status: TaskStatus,
    ) -> int:

        return (
            self.db.query(Task)
            .filter(
                Task.assigned_user_id == user_id,
                Task.status == task_status,
            )
            .count()
        )

    # ---------------------------------------------------------
    # OVERDUE TASKS
    # ---------------------------------------------------------

    def overdue_tasks(
        self,
        user_id: int,
    ) -> int:

        now = datetime.now(timezone.utc)

        return (
            self.db.query(Task)
            .filter(
                Task.assigned_user_id == user_id,
                Task.due_date.is_not(None),
                Task.due_date < now,
                Task.status.notin_(
                    [
                        TaskStatus.COMPLETED,
                        TaskStatus.CANCELLED,
                    ]
                ),
            )
            .count()
        )