from fastapi import FastAPI

from app.core.config import settings
from app.routers import (
    auth,
    users,
    tasks,
    comments,
    attachments,
    notifications
)
from app.routers import audit_logs
from app.routers import dashboard

app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="Task Management System REST API"
)


app.include_router(auth.router)
app.include_router(users.router)
app.include_router(tasks.router)
app.include_router(comments.router)
app.include_router(attachments.router)
app.include_router(notifications.router)
app.include_router(audit_logs.router)
app.include_router(
    dashboard.router
)

@app.get("/")
def root():
    return {
        "message": "Task Management System API is running"
    }


@app.get("/health")
def health_check():
    return {
        "status": "healthy"
    }