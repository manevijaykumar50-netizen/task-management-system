from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.dependencies import get_current_user, require_admin
from app.models.user import User
from app.schemas.dashboard import (
    AdminDashboardResponse,
    UserDashboardResponse,
)
from app.services.dashboard_service import DashboardService


router = APIRouter(
    prefix="/dashboard",
    tags=["Dashboard"],
)


# ---------------------------------------------------------
# ADMIN DASHBOARD
# ---------------------------------------------------------

@router.get(
    "/admin",
    response_model=AdminDashboardResponse,
)
def admin_dashboard(
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db),
):

    return DashboardService(
        db
    ).get_admin_dashboard()


# ---------------------------------------------------------
# USER DASHBOARD
# ---------------------------------------------------------

@router.get(
    "/me",
    response_model=UserDashboardResponse,
)
def user_dashboard(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):

    return DashboardService(
        db
    ).get_user_dashboard(
        current_user
    )