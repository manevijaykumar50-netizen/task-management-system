from fastapi import APIRouter, Depends, status

from sqlalchemy.orm import Session

from app.database import get_db
from app.dependencies import get_current_user
from app.models.user import User
from app.schemas.comment import (
    CommentCreateRequest,
    CommentResponse,
    CommentUpdateRequest,
)
from app.services.comment_service import CommentService


router = APIRouter(
    prefix="/comments",
    tags=["Comments"]
)


@router.post(
    "/tasks/{task_id}",
    response_model=CommentResponse,
    status_code=status.HTTP_201_CREATED
)
def create_comment(
    task_id: int,
    data: CommentCreateRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):

    service = CommentService(db)

    return service.create_comment(
        task_id=task_id,
        data=data,
        current_user=current_user
    )


@router.get(
    "/tasks/{task_id}",
    response_model=list[CommentResponse]
)
def get_comments(
    task_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):

    service = CommentService(db)

    return service.get_comments(
        task_id=task_id,
        current_user=current_user
    )


@router.put(
    "/{comment_id}",
    response_model=CommentResponse
)
def update_comment(
    comment_id: int,
    data: CommentUpdateRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):

    service = CommentService(db)

    return service.update_comment(
        comment_id=comment_id,
        data=data,
        current_user=current_user
    )


@router.delete(
    "/{comment_id}",
    status_code=status.HTTP_204_NO_CONTENT
)
def delete_comment(
    comment_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):

    service = CommentService(db)

    service.delete_comment(
        comment_id=comment_id,
        current_user=current_user
    )

    return None