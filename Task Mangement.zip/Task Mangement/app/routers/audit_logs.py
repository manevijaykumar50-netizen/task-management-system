from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.dependencies import require_admin
from app.models.user import User
from app.schemas.audit_log import AuditLogListResponse
from app.services.audit_log_service import AuditLogService


router = APIRouter(
    prefix="/audit-logs",
    tags=["Audit Logs"]
)


@router.get(
    "",
    response_model=AuditLogListResponse
)
def get_all_audit_logs(
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    service = AuditLogService(db)

    return service.get_all_logs()