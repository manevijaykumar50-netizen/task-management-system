from fastapi import APIRouter, Depends, Query, status

from app.database import get_db
from app.dependencies import require_admin
from app.schemas.user import (
    AdminCreateUserRequest,
    AdminUpdateUserRequest,
    UserResponse
)
from app.services.user_service import UserService
from sqlalchemy.orm import Session


router = APIRouter(
    prefix="/users",
    tags=["Users"],
    dependencies=[Depends(require_admin)]
)


@router.post(
    "",
    response_model=UserResponse,
    status_code=status.HTTP_201_CREATED
)
def create_user(
    data: AdminCreateUserRequest,
    db: Session = Depends(get_db)
):
    service = UserService(db)

    return service.create_user(data)


@router.get("")
def get_users(
    skip: int = Query(
        default=0,
        ge=0
    ),
    limit: int = Query(
        default=20,
        ge=1,
        le=100
    ),
    db: Session = Depends(get_db)
):
    service = UserService(db)

    return service.get_users(
        skip=skip,
        limit=limit
    )


@router.get(
    "/{user_id}",
    response_model=UserResponse
)
def get_user(
    user_id: int,
    db: Session = Depends(get_db)
):
    service = UserService(db)

    return service.get_user(user_id)


@router.put(
    "/{user_id}",
    response_model=UserResponse
)
def update_user(
    user_id: int,
    data: AdminUpdateUserRequest,
    db: Session = Depends(get_db)
):
    service = UserService(db)

    return service.update_user(
        user_id,
        data
    )


@router.delete(
    "/{user_id}"
)
def delete_user(
    user_id: int,
    db: Session = Depends(get_db)
):
    service = UserService(db)

    return service.delete_user(user_id)