from fastapi import APIRouter, Depends, File, UploadFile, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.dependencies import get_current_user
from app.models.user import User
from app.schemas.attachment import AttachmentResponse
from app.services.attachment_service import AttachmentService


router = APIRouter(
    prefix="/attachments",
    tags=["Attachments"]
)


@router.post(
    "/tasks/{task_id}",
    response_model=AttachmentResponse,
    status_code=status.HTTP_201_CREATED
)
def upload_attachment(
    task_id: int,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):

    service = AttachmentService(db)

    return service.upload_attachment(
        task_id=task_id,
        file=file,
        current_user=current_user
    )


@router.get(
    "/tasks/{task_id}",
    response_model=list[AttachmentResponse]
)
def get_attachments(
    task_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):

    service = AttachmentService(db)

    return service.get_attachments(
        task_id=task_id,
        current_user=current_user
    )


@router.delete(
    "/{attachment_id}",
    status_code=status.HTTP_204_NO_CONTENT
)
def delete_attachment(
    attachment_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):

    service = AttachmentService(db)

    service.delete_attachment(
        attachment_id=attachment_id,
        current_user=current_user
    )

    return None