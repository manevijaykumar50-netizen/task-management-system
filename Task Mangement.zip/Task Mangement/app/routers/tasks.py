from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.dependencies import get_current_user
from app.models.user import User
from app.schemas.task import (
    TaskAssignRequest,
    TaskCreateRequest,
    TaskPriorityRequest,
    TaskResponse,
    TaskStatusRequest,
    TaskUpdateRequest
)
from app.services.task_service import TaskService
from app.utils.enums import TaskPriority, TaskStatus


router = APIRouter(
    prefix="/tasks",
    tags=["Tasks"]
)


@router.post(
    "",
    response_model=TaskResponse,
    status_code=status.HTTP_201_CREATED
)
def create_task(
    data: TaskCreateRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):

    service = TaskService(db)

    return service.create_task(
        data,
        current_user
    )


@router.get("")
def get_tasks(
    page: int = Query(
        default=1,
        ge=1
    ),

    limit: int = Query(
        default=20,
        ge=1,
        le=100
    ),

    search: str | None = None,

    task_status: TaskStatus | None = Query(
        default=None,
        alias="status"
    ),

    priority: TaskPriority | None = None,

    assigned_user_id: int | None = Query(
        default=None,
        gt=0
    ),

    sort_by: str = Query(
        default="created_at"
    ),

    sort_order: str = Query(
        default="desc",
        pattern="^(asc|desc)$"
    ),

    current_user: User = Depends(
        get_current_user
    ),

    db: Session = Depends(get_db)
):

    service = TaskService(db)

    return service.get_tasks(
        current_user=current_user,
        page=page,
        limit=limit,
        search=search,
        task_status=task_status,
        priority=priority,
        assigned_user_id=assigned_user_id,
        sort_by=sort_by,
        sort_order=sort_order
    )


@router.get(
    "/{task_id}",
    response_model=TaskResponse
)
def get_task(
    task_id: int,
    current_user: User = Depends(
        get_current_user
    ),
    db: Session = Depends(get_db)
):

    service = TaskService(db)

    return service.get_task(
        task_id,
        current_user
    )


@router.put(
    "/{task_id}",
    response_model=TaskResponse
)
def update_task(
    task_id: int,
    data: TaskUpdateRequest,
    current_user: User = Depends(
        get_current_user
    ),
    db: Session = Depends(get_db)
):

    service = TaskService(db)

    return service.update_task(
        task_id,
        data,
        current_user
    )


@router.delete(
    "/{task_id}"
)
def delete_task(
    task_id: int,
    current_user: User = Depends(
        get_current_user
    ),
    db: Session = Depends(get_db)
):

    service = TaskService(db)

    return service.delete_task(
        task_id,
        current_user
    )


@router.put("/{task_id}/assign", response_model=TaskResponse)
def assign_task(
    task_id: int,
    data: TaskAssignRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    return TaskService(db).assign_task(
        task_id,
        data.assigned_user_id,
        current_user
    )


@router.put(
    "/{task_id}/status",
    response_model=TaskResponse
)
def change_status(
    task_id: int,
    data: TaskStatusRequest,
    current_user: User = Depends(
        get_current_user
    ),
    db: Session = Depends(get_db)
):

    service = TaskService(db)

    return service.change_status(
        task_id,
        data,
        current_user
    )


@router.put(
    "/{task_id}/priority",
    response_model=TaskResponse
)
def change_priority(
    task_id: int,
    data: TaskPriorityRequest,
    current_user: User = Depends(
        get_current_user
    ),
    db: Session = Depends(get_db)
):

    service = TaskService(db)

    return service.change_priority(
        task_id,
        data,
        current_user
    )