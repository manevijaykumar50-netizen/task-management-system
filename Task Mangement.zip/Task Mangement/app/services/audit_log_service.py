from app.models.audit_log import AuditLog
from app.repositories.audit_log_repository import AuditLogRepository
from app.schemas.audit_log import AuditLogListResponse
from app.utils.enums import AuditAction, EntityType


class AuditLogService:

    def __init__(self, db):
        self.db = db
        self.repository = AuditLogRepository(db)

    def create_log(
        self,
        user_id: int,
        action: AuditAction,
        entity_type: EntityType,
        entity_id: int
    ) -> AuditLog:

        audit_log = AuditLog(
            user_id=user_id,
            action=action,
            entity_type=entity_type,
            entity_id=entity_id
        )

        return self.repository.create(audit_log)

    def get_all_logs(self) -> AuditLogListResponse:

        logs = self.repository.get_all()
        total = self.repository.count()

        return AuditLogListResponse(
            items=logs,
            total=total
        )

    def get_user_logs(
        self,
        user_id: int
    ) -> list[AuditLog]:

        return self.repository.get_by_user(user_id)

    def get_entity_logs(
        self,
        entity_type: EntityType,
        entity_id: int
    ) -> list[AuditLog]:

        return self.repository.get_by_entity(
            entity_type=entity_type,
            entity_id=entity_id
        )