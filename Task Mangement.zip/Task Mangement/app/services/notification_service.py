from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.models.notification import Notification
from app.repositories.notification_repository import NotificationRepository
from app.schemas.notification import NotificationListResponse
from app.utils.enums import NotificationType


class NotificationService:

    def __init__(self, db: Session):
        self.db = db
        self.repository = NotificationRepository(db)

    def create_notification(
        self,
        user_id: int,
        notification_type: NotificationType,
        title: str,
        message: str
    ) -> Notification:

        notification = Notification(
            user_id=user_id,
            type=notification_type,
            title=title,
            message=message,
            is_read=False
        )

        return self.repository.create(notification)

    def get_notifications(
        self,
        user_id: int,
        unread_only: bool = False
    ) -> NotificationListResponse:

        notifications = self.repository.get_by_user(
            user_id=user_id,
            unread_only=unread_only
        )

        total = self.repository.count_by_user(user_id)
        unread_count = self.repository.count_unread(user_id)

        return NotificationListResponse(
            items=notifications,
            total=total,
            unread_count=unread_count
        )

    def mark_as_read(
        self,
        notification_id: int,
        user_id: int
    ) -> Notification:

        notification = self.repository.get_by_id(notification_id)

        if not notification:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Notification not found"
            )

        if notification.user_id != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You can only modify your own notifications"
            )

        notification.is_read = True

        return self.repository.update(notification)

    def delete_notification(
        self,
        notification_id: int,
        user_id: int
    ) -> None:

        notification = self.repository.get_by_id(notification_id)

        if not notification:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Notification not found"
            )

        if notification.user_id != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You can only delete your own notifications"
            )

        self.repository.delete(notification)