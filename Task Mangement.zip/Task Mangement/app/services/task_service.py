from datetime import datetime, timezone
from math import ceil

from fastapi import HTTPException, status
from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.models.task import Task
from app.models.user import User
from app.repositories.task_repository import TaskRepository
from app.schemas.task import (
    TaskCreateRequest,
    TaskPriorityRequest,
    TaskStatusRequest,
    TaskUpdateRequest,
)
from app.services.audit_log_service import AuditLogService
from app.services.notification_service import NotificationService
from app.utils.enums import (
    AuditAction,
    EntityType,
    NotificationType,
    TaskPriority,
    TaskStatus,
    UserRole,
    UserStatus,
)


class TaskService:

    def __init__(self, db: Session):
        self.db = db
        self.repository = TaskRepository(db)

    # ---------------------------------------------------------
    # GET TASK
    # ---------------------------------------------------------

    def _get_task(self, task_id: int) -> Task:

        task = self.repository.get_by_id(task_id)

        if not task:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Task not found",
            )

        return task

    # ---------------------------------------------------------
    # GET USER
    # ---------------------------------------------------------

    def _get_user(self, user_id: int) -> User:

        user = (
            self.db.query(User)
            .filter(User.id == user_id)
            .first()
        )

        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found",
            )

        return user

    # ---------------------------------------------------------
    # CHECK TASK ACCESS
    # ---------------------------------------------------------

    def _check_access(
        self,
        task: Task,
        current_user: User,
    ) -> None:

        # Admin can access all tasks
        if current_user.role == UserRole.ADMIN:
            return

        # Task creator can access
        if task.created_by_id == current_user.id:
            return

        # Assigned user can access
        if task.assigned_user_id == current_user.id:
            return

        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You are not authorized to access this task",
        )

    # ---------------------------------------------------------
    # CHECK TASK MODIFIABLE
    # ---------------------------------------------------------

    def _ensure_task_modifiable(
        self,
        task: Task,
    ) -> None:

        if task.status == TaskStatus.COMPLETED:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Completed tasks cannot be modified",
            )

        if task.status == TaskStatus.CANCELLED:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Cancelled tasks cannot be modified",
            )

    # ---------------------------------------------------------
    # CREATE TASK
    # ---------------------------------------------------------

    def create_task(
        self,
        data: TaskCreateRequest,
        current_user: User,
    ) -> Task:

        # Validate assigned user
        if data.assigned_user_id is not None:

            assigned_user = self._get_user(
                data.assigned_user_id
            )

            if assigned_user.status != UserStatus.ACTIVE:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Inactive users cannot be assigned tasks",
                )

        # Create task
        task = Task(
            title=data.title,
            description=data.description,
            assigned_user_id=data.assigned_user_id,
            created_by_id=current_user.id,
            priority=data.priority,
            status=TaskStatus.TODO,
            due_date=data.due_date,
        )

        task = self.repository.create(task)

        # Audit CREATE
        AuditLogService(self.db).create_log(
            user_id=current_user.id,
            action=AuditAction.CREATE,
            entity_type=EntityType.TASK,
            entity_id=task.id,
        )

        # Notification
        if data.assigned_user_id is not None:

            NotificationService(self.db).create_notification(
                user_id=data.assigned_user_id,
                notification_type=NotificationType.TASK_ASSIGNED,
                title="Task Assigned",
                message=f"You have been assigned task: {task.title}",
            )

        return task

    # ---------------------------------------------------------
    # GET SINGLE TASK
    # ---------------------------------------------------------

    def get_task(
        self,
        task_id: int,
        current_user: User,
    ) -> Task:

        task = self._get_task(task_id)

        self._check_access(
            task,
            current_user,
        )

        return task

    # ---------------------------------------------------------
    # GET TASK LIST
    # ---------------------------------------------------------

    def get_tasks(
        self,
        current_user: User,
        page: int = 1,
        limit: int = 20,
        search: str | None = None,
        task_status: TaskStatus | None = None,
        priority: TaskPriority | None = None,
        assigned_user_id: int | None = None,
        sort_by: str = "created_at",
        sort_order: str = "desc",
    ):

        # Validate pagination
        if page < 1:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Page must be greater than 0",
            )

        if limit < 1 or limit > 100:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Limit must be between 1 and 100",
            )

        query = self.db.query(Task)

        # -----------------------------------------------------
        # USER ACCESS
        # -----------------------------------------------------

        if current_user.role != UserRole.ADMIN:

            query = query.filter(
                or_(
                    Task.created_by_id == current_user.id,
                    Task.assigned_user_id == current_user.id,
                )
            )

        # -----------------------------------------------------
        # SEARCH
        # -----------------------------------------------------

        if search:

            search_value = f"%{search}%"

            query = query.filter(
                or_(
                    Task.title.ilike(search_value),
                    Task.description.ilike(search_value),
                )
            )

        # -----------------------------------------------------
        # STATUS FILTER
        # -----------------------------------------------------

        if task_status:

            query = query.filter(
                Task.status == task_status
            )

        # -----------------------------------------------------
        # PRIORITY FILTER
        # -----------------------------------------------------

        if priority:

            query = query.filter(
                Task.priority == priority
            )

        # -----------------------------------------------------
        # ASSIGNED USER FILTER
        # -----------------------------------------------------

        if assigned_user_id:

            query = query.filter(
                Task.assigned_user_id == assigned_user_id
            )

        # -----------------------------------------------------
        # SORTING
        # -----------------------------------------------------

        allowed_sort_columns = {
            "id": Task.id,
            "title": Task.title,
            "priority": Task.priority,
            "status": Task.status,
            "due_date": Task.due_date,
            "created_at": Task.created_at,
            "updated_at": Task.updated_at,
        }

        sort_column = allowed_sort_columns.get(
            sort_by,
            Task.created_at,
        )

        if sort_order.lower() == "asc":

            query = query.order_by(
                sort_column.asc()
            )

        else:

            query = query.order_by(
                sort_column.desc()
            )

        # -----------------------------------------------------
        # TOTAL
        # -----------------------------------------------------

        total = query.count()

        pages = ceil(total / limit) if total else 0

        if pages and page > pages:

            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Page does not exist",
            )

        # -----------------------------------------------------
        # PAGINATION
        # -----------------------------------------------------

        tasks = self.repository.get_tasks(
            query,
            page,
            limit,
        )

        return {
            "items": tasks,
            "total": total,
            "page": page,
            "limit": limit,
            "pages": pages,
        }

    # ---------------------------------------------------------
    # UPDATE TASK
    # ---------------------------------------------------------

    def update_task(
        self,
        task_id: int,
        data: TaskUpdateRequest,
        current_user: User,
    ) -> Task:

        task = self._get_task(task_id)

        self._check_access(
            task,
            current_user,
        )

        self._ensure_task_modifiable(task)

        # Update title
        if data.title is not None:
            task.title = data.title

        # Update description
        if data.description is not None:
            task.description = data.description

        # Update due date
        if data.due_date is not None:
            task.due_date = data.due_date

        task = self.repository.update(task)

        # Audit UPDATE
        AuditLogService(self.db).create_log(
            user_id=current_user.id,
            action=AuditAction.UPDATE,
            entity_type=EntityType.TASK,
            entity_id=task.id,
        )

        return task

    # ---------------------------------------------------------
    # DELETE TASK
    # ---------------------------------------------------------

    def delete_task(
        self,
        task_id: int,
        current_user: User,
    ):

        task = self._get_task(task_id)

        self._check_access(
            task,
            current_user,
        )

        # Completed tasks cannot be deleted
        if task.status == TaskStatus.COMPLETED:

            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Completed tasks cannot be deleted",
            )

        # Cancelled tasks cannot be deleted
        if task.status == TaskStatus.CANCELLED:

            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Cancelled tasks cannot be deleted",
            )

        # Save ID before deleting
        deleted_task_id = task.id

        self.repository.delete(task)

        # Audit DELETE
        AuditLogService(self.db).create_log(
            user_id=current_user.id,
            action=AuditAction.DELETE,
            entity_type=EntityType.TASK,
            entity_id=deleted_task_id,
        )

        return {
            "message": "Task deleted successfully"
        }

    # ---------------------------------------------------------
    # ASSIGN TASK
    # ---------------------------------------------------------

    def assign_task(
        self,
        task_id: int,
        assigned_user_id: int,
        current_user: User,
    ) -> Task:

        task = self._get_task(task_id)

        self._check_access(
            task,
            current_user,
        )

        self._ensure_task_modifiable(task)

        # Validate assigned user
        assigned_user = self._get_user(
            assigned_user_id
        )

        if assigned_user.status != UserStatus.ACTIVE:

            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Inactive users cannot be assigned tasks",
            )

        previous_assigned_user_id = (
            task.assigned_user_id
        )

        task.assigned_user_id = assigned_user_id

        task = self.repository.update(task)

        # Audit ASSIGN
        AuditLogService(self.db).create_log(
            user_id=current_user.id,
            action=AuditAction.ASSIGN,
            entity_type=EntityType.TASK,
            entity_id=task.id,
        )

        # Notification service
        notification_service = NotificationService(
            self.db
        )

        # First assignment
        if previous_assigned_user_id is None:

            notification_service.create_notification(
                user_id=assigned_user_id,
                notification_type=NotificationType.TASK_ASSIGNED,
                title="Task Assigned",
                message=f"You have been assigned task: {task.title}",
            )

        # Reassignment
        elif previous_assigned_user_id != assigned_user_id:

            notification_service.create_notification(
                user_id=assigned_user_id,
                notification_type=NotificationType.TASK_REASSIGNED,
                title="Task Reassigned",
                message=f"Task '{task.title}' has been assigned to you",
            )

        return task

    # ---------------------------------------------------------
    # CHANGE STATUS
    # ---------------------------------------------------------

    def change_status(
        self,
        task_id: int,
        data: TaskStatusRequest,
        current_user: User,
    ) -> Task:

        task = self._get_task(task_id)

        self._check_access(
            task,
            current_user,
        )

        self._ensure_task_modifiable(task)

        current_status = task.status

        new_status = data.status

        # -----------------------------------------------------
        # VALID STATUS TRANSITIONS
        # -----------------------------------------------------

        valid_transitions = {
            TaskStatus.TODO: [
                TaskStatus.IN_PROGRESS,
                TaskStatus.CANCELLED,
            ],
            TaskStatus.IN_PROGRESS: [
                TaskStatus.COMPLETED,
                TaskStatus.CANCELLED,
            ],
        }

        if new_status not in valid_transitions.get(
            current_status,
            [],
        ):

            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=(
                    f"Invalid status transition from "
                    f"{current_status.value} to "
                    f"{new_status.value}"
                ),
            )

        # -----------------------------------------------------
        # UPDATE STATUS
        # -----------------------------------------------------

        task.status = new_status

        # Set completed timestamp
        if new_status == TaskStatus.COMPLETED:

            task.completed_at = datetime.now(
                timezone.utc
            )

        task = self.repository.update(task)

        # -----------------------------------------------------
        # AUDIT STATUS CHANGE
        # -----------------------------------------------------

        AuditLogService(self.db).create_log(
            user_id=current_user.id,
            action=AuditAction.STATUS_CHANGE,
            entity_type=EntityType.TASK,
            entity_id=task.id,
        )

        # -----------------------------------------------------
        # NOTIFICATION
        # -----------------------------------------------------

        if task.assigned_user_id:

            notification_type = (
                NotificationType.TASK_COMPLETED
                if new_status == TaskStatus.COMPLETED
                else NotificationType.STATUS_CHANGED
            )

            NotificationService(self.db).create_notification(
                user_id=task.assigned_user_id,
                notification_type=notification_type,
                title="Task Status Changed",
                message=(
                    f"Task '{task.title}' status changed "
                    f"from {current_status.value} "
                    f"to {new_status.value}"
                ),
            )

        return task

    # ---------------------------------------------------------
    # CHANGE PRIORITY
    # ---------------------------------------------------------

    def change_priority(
        self,
        task_id: int,
        data: TaskPriorityRequest,
        current_user: User,
    ) -> Task:

        task = self._get_task(task_id)

        self._check_access(
            task,
            current_user,
        )

        self._ensure_task_modifiable(task)

        task.priority = data.priority

        task = self.repository.update(task)

        # -----------------------------------------------------
        # AUDIT PRIORITY CHANGE
        # -----------------------------------------------------

        AuditLogService(self.db).create_log(
            user_id=current_user.id,
            action=AuditAction.PRIORITY_CHANGE,
            entity_type=EntityType.TASK,
            entity_id=task.id,
        )

        return task