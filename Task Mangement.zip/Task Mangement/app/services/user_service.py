from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.core.security import hash_password
from app.models.user import User
from app.repositories.user_repository import UserRepository
from app.schemas.user import (
    AdminCreateUserRequest,
    AdminUpdateUserRequest
)
from app.utils.enums import UserStatus


class UserService:

    def __init__(self, db: Session):
        self.repository = UserRepository(db)

    def create_user(
        self,
        data: AdminCreateUserRequest
    ) -> User:

        existing_user = self.repository.get_by_email(
            data.email
        )

        if existing_user:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Email already registered"
            )

        user = User(
            name=data.name,
            email=data.email,
            phone=data.phone,
            hashed_password=hash_password(
                data.password
            ),
            role=data.role,
            status=UserStatus.ACTIVE
        )

        return self.repository.create(user)

    def get_user(
        self,
        user_id: int
    ) -> User:

        user = self.repository.get_by_id(user_id)

        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )

        return user

    def get_users(
        self,
        skip: int = 0,
        limit: int = 100
    ):

        users = self.repository.get_all(
            skip=skip,
            limit=limit
        )

        total = self.repository.count()

        return {
            "items": users,
            "total": total,
            "skip": skip,
            "limit": limit
        }

    def update_user(
        self,
        user_id: int,
        data: AdminUpdateUserRequest
    ) -> User:

        user = self.get_user(user_id)

        if data.email is not None:
            existing_user = self.repository.get_by_email(
                data.email
            )

            if (
                existing_user
                and existing_user.id != user.id
            ):
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail="Email already registered"
                )

            user.email = data.email

        if data.name is not None:
            user.name = data.name

        if data.phone is not None:
            user.phone = data.phone

        if data.role is not None:
            user.role = data.role

        if data.status is not None:
            user.status = data.status

        return self.repository.update(user)

    def deactivate_user(
        self,
        user_id: int
    ) -> User:

        user = self.get_user(user_id)

        user.status = UserStatus.INACTIVE

        return self.repository.update(user)

    def delete_user(
        self,
        user_id: int
    ):

        user = self.get_user(user_id)

        self.repository.delete(user)

        return {
            "message": "User deleted successfully"
        }