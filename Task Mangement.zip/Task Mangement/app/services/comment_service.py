from datetime import datetime, timezone

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.models.comment import Comment
from app.models.task import Task
from app.models.user import User
from app.repositories.comment_repository import CommentRepository
from app.schemas.comment import (
    CommentCreateRequest,
    CommentUpdateRequest,
)
from app.utils.enums import TaskStatus, UserRole, UserStatus


class CommentService:

    def __init__(self, db: Session):
        self.db = db
        self.repository = CommentRepository(db)

    def _get_task(self, task_id: int) -> Task:
        task = (
            self.db.query(Task)
            .filter(Task.id == task_id)
            .first()
        )

        if not task:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Task not found"
            )

        return task

    def _get_comment(self, comment_id: int) -> Comment:
        comment = self.repository.get_by_id(comment_id)

        if not comment:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Comment not found"
            )

        return comment

    def _check_task_access(
        self,
        task: Task,
        current_user: User
    ) -> None:

        if current_user.role == UserRole.ADMIN:
            return

        if (
            task.created_by_id != current_user.id
            and task.assigned_user_id != current_user.id
        ):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You do not have access to this task"
            )

    def _check_comment_modification(
        self,
        comment: Comment,
        current_user: User
    ) -> None:

        if current_user.role == UserRole.ADMIN:
            return

        if comment.user_id != current_user.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You can modify only your own comments"
            )

    def create_comment(
        self,
        task_id: int,
        data: CommentCreateRequest,
        current_user: User
    ) -> Comment:

        if current_user.status != UserStatus.ACTIVE:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Inactive users cannot create comments"
            )

        task = self._get_task(task_id)

        self._check_task_access(task, current_user)

        # Completed and cancelled tasks cannot receive comments
        if task.status in (
            TaskStatus.COMPLETED,
            TaskStatus.CANCELLED
        ):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Completed or cancelled tasks cannot receive new comments"
            )

        comment = Comment(
            task_id=task.id,
            user_id=current_user.id,
            content=data.content,
        )

        return self.repository.create(comment)

    def get_comments(
        self,
        task_id: int,
        current_user: User
    ) -> list[Comment]:

        task = self._get_task(task_id)

        self._check_task_access(task, current_user)

        return self.repository.get_by_task(task_id)

    def update_comment(
        self,
        comment_id: int,
        data: CommentUpdateRequest,
        current_user: User
    ) -> Comment:

        comment = self._get_comment(comment_id)

        self._check_comment_modification(comment, current_user)

        task = self._get_task(comment.task_id)

        self._check_task_access(task, current_user)

        # Existing comments cannot be modified after task completion/cancellation
        if task.status in (
            TaskStatus.COMPLETED,
            TaskStatus.CANCELLED
        ):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Comments on completed or cancelled tasks cannot be modified"
            )

        comment.content = data.content
        comment.updated_at = datetime.now(timezone.utc)

        return self.repository.update(comment)

    def delete_comment(
        self,
        comment_id: int,
        current_user: User
    ) -> None:

        comment = self._get_comment(comment_id)

        self._check_comment_modification(comment, current_user)

        task = self._get_task(comment.task_id)

        self._check_task_access(task, current_user)

        self.repository.delete(comment)