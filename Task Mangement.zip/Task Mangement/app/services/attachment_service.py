from pathlib import Path
from uuid import uuid4

from fastapi import HTTPException, UploadFile, status
from sqlalchemy.orm import Session

from app.models.attachment import Attachment
from app.models.task import Task
from app.models.user import User
from app.repositories.attachment_repository import AttachmentRepository
from app.utils.enums import TaskStatus, UserRole, UserStatus


class AttachmentService:

    MAX_FILE_SIZE = 5 * 1024 * 1024  # 5 MB

    ALLOWED_EXTENSIONS = {
        ".pdf",
        ".png",
        ".jpg",
        ".jpeg",
        ".txt",
        ".doc",
        ".docx",
        ".xls",
        ".xlsx",
        ".csv",
    }

    def __init__(self, db: Session):
        self.db = db
        self.repository = AttachmentRepository(db)

        self.upload_dir = Path("uploads")

        self.upload_dir.mkdir(
            parents=True,
            exist_ok=True
        )

    def _get_task(self, task_id: int) -> Task:

        task = (
            self.db.query(Task)
            .filter(Task.id == task_id)
            .first()
        )

        if not task:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Task not found"
            )

        return task

    def _get_attachment(
        self,
        attachment_id: int
    ) -> Attachment:

        attachment = self.repository.get_by_id(
            attachment_id
        )

        if not attachment:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Attachment not found"
            )

        return attachment

    def _check_task_access(
        self,
        task: Task,
        current_user: User
    ) -> None:

        if current_user.role == UserRole.ADMIN:
            return

        if (
            task.created_by_id != current_user.id
            and task.assigned_user_id != current_user.id
        ):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You do not have access to this task"
            )

    def upload_attachment(
        self,
        task_id: int,
        file: UploadFile,
        current_user: User
    ) -> Attachment:

        if current_user.status != UserStatus.ACTIVE:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Inactive users cannot upload attachments"
            )

        task = self._get_task(task_id)

        self._check_task_access(
            task,
            current_user
        )

        # Completed/cancelled tasks cannot receive attachments
        if task.status in (
            TaskStatus.COMPLETED,
            TaskStatus.CANCELLED
        ):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Completed or cancelled tasks cannot receive attachments"
            )

        if not file.filename:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Filename is required"
            )

        # Get extension safely
        extension = Path(file.filename).suffix.lower()

        if extension not in self.ALLOWED_EXTENSIONS:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=(
                    "Unsupported file type. "
                    "Allowed types: PDF, PNG, JPG, JPEG, TXT, "
                    "DOC, DOCX, XLS, XLSX, CSV"
                )
            )

        # Read file
        file_data = file.file.read()

        file_size = len(file_data)

        if file_size == 0:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Cannot upload an empty file"
            )

        if file_size > self.MAX_FILE_SIZE:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="File size cannot exceed 5 MB"
            )

        # Generate unique filename
        stored_filename = (
            f"{uuid4().hex}{extension}"
        )

        file_path = self.upload_dir / stored_filename

        try:
            with open(file_path, "wb") as destination:
                destination.write(file_data)

        except Exception:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to save file"
            )

        attachment = Attachment(
            task_id=task.id,
            uploaded_by_id=current_user.id,
            original_filename=file.filename,
            stored_filename=stored_filename,
            file_path=str(file_path),
            file_type=file.content_type or "application/octet-stream",
            file_size=file_size,
        )

        return self.repository.create(attachment)

    def get_attachments(
        self,
        task_id: int,
        current_user: User
    ) -> list[Attachment]:

        task = self._get_task(task_id)

        self._check_task_access(
            task,
            current_user
        )

        return self.repository.get_by_task(task_id)

    def delete_attachment(
        self,
        attachment_id: int,
        current_user: User
    ) -> None:

        attachment = self._get_attachment(
            attachment_id
        )

        task = self._get_task(
            attachment.task_id
        )

        self._check_task_access(
            task,
            current_user
        )

        # Only owner or admin can delete
        if (
            current_user.role != UserRole.ADMIN
            and attachment.uploaded_by_id != current_user.id
        ):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You can delete only your own attachments"
            )

        # Delete physical file
        file_path = Path(attachment.file_path)

        if file_path.exists():
            try:
                file_path.unlink()
            except OSError:
                pass

        self.repository.delete(attachment)