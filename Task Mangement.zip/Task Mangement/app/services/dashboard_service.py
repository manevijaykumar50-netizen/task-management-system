from sqlalchemy.orm import Session

from app.models.user import User
from app.repositories.dashboard_repository import DashboardRepository
from app.schemas.dashboard import (
    AdminDashboardResponse,
    TaskPrioritySummary,
    TaskStatusSummary,
    UserDashboardResponse,
)
from app.utils.enums import TaskPriority, TaskStatus


class DashboardService:

    def __init__(self, db: Session):

        self.db = db
        self.repository = DashboardRepository(db)

    # ---------------------------------------------------------
    # ADMIN DASHBOARD
    # ---------------------------------------------------------

    def get_admin_dashboard(
        self,
    ) -> AdminDashboardResponse:

        return AdminDashboardResponse(

            total_users=self.repository.total_users(),

            active_users=self.repository.active_users(),

            inactive_users=self.repository.inactive_users(),

            total_tasks=self.repository.total_tasks(),

            task_status=TaskStatusSummary(

                todo=self.repository.tasks_by_status(
                    TaskStatus.TODO
                ),

                in_progress=self.repository.tasks_by_status(
                    TaskStatus.IN_PROGRESS
                ),

                completed=self.repository.tasks_by_status(
                    TaskStatus.COMPLETED
                ),

                cancelled=self.repository.tasks_by_status(
                    TaskStatus.CANCELLED
                ),
            ),

            task_priority=TaskPrioritySummary(

                low=self.repository.tasks_by_priority(
                    TaskPriority.LOW
                ),

                medium=self.repository.tasks_by_priority(
                    TaskPriority.MEDIUM
                ),

                high=self.repository.tasks_by_priority(
                    TaskPriority.HIGH
                ),

                critical=self.repository.tasks_by_priority(
                    TaskPriority.CRITICAL
                ),
            ),
        )

    # ---------------------------------------------------------
    # USER DASHBOARD
    # ---------------------------------------------------------

    def get_user_dashboard(
        self,
        current_user: User,
    ) -> UserDashboardResponse:

        user_id = current_user.id

        return UserDashboardResponse(

            created_tasks=self.repository.created_tasks(
                user_id
            ),

            assigned_tasks=self.repository.assigned_tasks(
                user_id
            ),

            todo_tasks=self.repository.user_tasks_by_status(
                user_id,
                TaskStatus.TODO,
            ),

            in_progress_tasks=self.repository.user_tasks_by_status(
                user_id,
                TaskStatus.IN_PROGRESS,
            ),

            completed_tasks=self.repository.user_tasks_by_status(
                user_id,
                TaskStatus.COMPLETED,
            ),

            cancelled_tasks=self.repository.user_tasks_by_status(
                user_id,
                TaskStatus.CANCELLED,
            ),

            overdue_tasks=self.repository.overdue_tasks(
                user_id
            ),
        )